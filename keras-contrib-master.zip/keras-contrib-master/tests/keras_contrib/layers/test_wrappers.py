import pytest
import numpy as np
from numpy.testing import assert_allclose
from keras.utils.test_utils import keras_test
from keras_contrib.layers import wrappers


if __name__ == '__main__':
    pytest.main([__file__])
