from __future__ import print_function
import pytest
import time
import random
from keras_contrib import datasets


if __name__ == '__main__':
    pytest.main([__file__])
