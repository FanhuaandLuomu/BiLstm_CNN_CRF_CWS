from .ftml import FTML

# aliases
ftml = FTML
